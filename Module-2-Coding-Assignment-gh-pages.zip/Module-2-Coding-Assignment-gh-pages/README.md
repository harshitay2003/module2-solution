# Module-2-Coding-Assignment
Coursera course: HTML, CSS, and Javascript for Web Developers
